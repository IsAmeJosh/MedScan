# MedScan: context for Claude Code

Claude Code reads this file automatically at the start of every session. Keep it at the repo root.

## What MedScan is
A Django class project (Module 2, live demo to panelists on October 19, 2026). A patient record system where doctors open a patient's record only with the patient's consent. A patient approves a request, or shows their QR code in person for the doctor to scan. Emergency access is the exception, and it is always logged. SDGs 3 and 9.

Demo accounts: patient 1001 / pat123, doctor 2001 / doc123. The ID decides the role: IDs starting with 1 are patients, 2 are doctors. To test both roles at once, use a normal window and an Incognito window side by side.

## Code layout (MVC, one class per file)
- `models/` (prefix M_): M_User, M_Patient, M_Doctor, M_Medical_Record, M_Consultation, M_Access_Request, M_Emergency_Log, M_Notification, M_QR_Code.
- `logic/` (prefix L_): L_MedScan_System.py holds MedScanSystem, which ties everything together and saves with its own save().
- `gui/` (prefix G_): G_Views.py, templates in gui/templates/G_*.html, CSS in gui/static/css/G_Style.css, icons in G_Icons.py.
- `Main_Driver.py`: console demo only.
- Tests: `python manage.py test`.

## Rules (from the project owner)
- Functionality before appearance. Make the logic work first.
- All OOP and DSA logic stays in the model and logic classes. G_Views.py stays thin and only calls MedScanSystem methods (the "remote" rule: the GUI never reaches into its dicts and lists).
- Check what exists before adding anything. Don't duplicate classes or methods.
- Keep code simple enough for a student to explain line by line. Point out the OOP concept each piece shows: encapsulation, inheritance, polymorphism, abstraction.
- Data lives in MySQL (XAMPP, database db_medscan, tables prefixed tb_; see database/schema.sql and seed.sql). The old pickle/save() storage is obsolete.
- Give each changed file in full, say where it lives, and how to test it.
- Windows, VS Code and PowerShell commands.
- snake_case methods, PascalCase classes, a docstring on every class and method.
- The Streamlit files (medscan_*.py) are an old prototype. Don't build on them.

## UI decisions (latest: 2026-10-18, design v9)
The full spec is in `design-v9/HANDOFF.md`, with reference pages in `design-v9/reference/` and screenshots in `design-v9/screens/`. It refines the v6 UI and does not replace it. In short:
- **Style "Calm Clinical", scheme "Teal Shell":** the page is #EEF4F3, cards are white, text is #12333A, and the brand teal is #0E7C7B. Green = approved, amber = pending, red = danger only.
- **Four materials only:** base, white surface, one brand gradient (sidebar, ID card and primary buttons only) and glass (top bar and phone tab bar only). Pop-ups dim and blur the page.
- **Boxes:** one box per thing you act on or per group of rows. No box inside a box, and at most 3 per PC screen.
- **Responsive:** phone below 600px with bottom tabs (5 equal slots, My QR in the middle, a flat full-width bar), an icon rail at 600 to 1023px, a sidebar from 1024px, and two columns from 1280px.
- **Roles:** patients only SHOW their QR code, and doctors only SCAN.
- **Patient nav:** Home, My Record (Notes, Care history, Medical, Info), Access (Requests, Doctors, History), Profile, Settings, plus "Show my QR code". On phone, Settings opens from the gear in the top bar of every page.
- **Doctor nav:** Home, Patients, Profile, Settings, plus "Scan QR code". There is one Patient page with locked and open states.
- **One home per action:** log out only in Settings. Notifications are pointers in the bell panel.
- **Ethics:** Allow and Decline have equal weight, there is no count strip, no contact number on Home, the patient can hide a care-history entry, and the password never appears on the ID PDF.
- **Care history items are demo placeholders.** Admissions and ER visits need new tables after the exam.

## QR access
The QR holds a one-time token that expires after 5 minutes, and a scan auto-approves. A plain patient ID never approves access.

## How to build the UI (follow exactly, don't improvise)
- The reference pages in `design-v9/reference/` are the source of truth. Each template must match its reference page: same sections, same order, same headings, same wording, same classes. If the reference and this file disagree, the reference wins.
- Before editing a template, open its reference page and list every section, heading and button it has. After editing, check the template against that list and report anything still different.
- Don't add anything the reference doesn't have: no extra text, helper sentences, icons, panels, colours, shadows or animations. Don't remove anything it has.
- Use only the classes and values in `design-v9/css/s1.css` to `s8.css`. No new hex colours, font sizes or spacing values, and no inline styles unless the reference has them.
- Layout (s8): every page uses the same header (title, optional status pill, one line under it), underline tabs directly under it, and either main + 360px side column or two equal halves. Panels start and end on the content edges, and both columns end on the same line. No loose helper text under panels.
- Placeholders (care history, vaccinations, recent scans, language and other toggles) are hard-coded in the template and marked `{# demo placeholder #}`. No new models, tables or views for them.
- `design-v9/FEATURES.md` says which features must work (A), can work quickly (B), and stay placeholders (C, D). Follow it. Never build C or D as real features before the exam.
- One step at a time. Do only the step asked for, then stop and say how to test it. If something can't match the reference without changing logic, ask first.
