# What should work, and what stays a placeholder

Sorted against the models listed in CLAUDE.md (M_User, M_Patient, M_Doctor, M_Medical_Record, M_Consultation, M_Access_Request, M_Emergency_Log, M_Notification, M_QR_Code). Where a group says "already", that was inferred from the model list. Check that the method really exists before relying on it.

- **A. Must work.** This is the core of the demo, and the models already exist. Wire it to real data.
- **B. Can work, short job.** Under about an hour each, using existing tables or the browser only, with no schema change. Do these only after A is solid.
- **C. Placeholder for the demo.** It would need new tables, columns or a bigger feature. Hard-code it in the template with `{# demo placeholder #}`. It looks real, but nothing behind it changes.
- **D. Placeholder, long-term only.** It needs outside systems or a lot of work. Don't try it before the exam.

## A. Must work
| Screen | Feature |
|---|---|
| Log in | Log in with MedScan ID and password, wrong-password error |
| Create account | Register patient or doctor, DOB calendar, get a new ID |
| Save your ID | Shows the new ID after registering |
| Home (patient) | ID card: name, sex, age, blood type, allergies from the medical record |
| Home, Access: Requests | Allow and Decline a doctor's request |
| QR pop-up | One-time token, 5-minute expiry, the doctor's scan opens the record |
| Access: Doctors | List doctors with access, Remove access |
| Access: History | Every scan, open, emergency access and decline, permanent |
| My Record: Notes | Consultation notes, newest first |
| My Record: Medical | Allergies, medications, past surgeries, blood type (from M_Medical_Record) |
| Doctor: Patients | List of patients the doctor can see or has asked |
| Doctor: patient locked | Send access request, Scan QR |
| Doctor: Emergency access | Reason required, logged, patient notified |
| Doctor: open record | Read the record, add a consultation note |
| Doctor: Find a patient | Search by ID, shows the record as locked |
| Notifications (bell) | List from M_Notification, mark all as read |
| Settings | Log out (and its confirmation) |

## B. Can work, short job (existing data, no new tables)
| Screen | Feature | How |
|---|---|---|
| Home after Allow | Teal toast, "You're all caught up" | Django messages plus an empty-state check |
| QR expired | Expired sheet, Make a new code | The token already expires, so just show the state |
| Home, ID card | Taking, Last visit | Medication from the record, date of the latest consultation |
| Home | Your care team | Distinct doctors from consultations and access |
| Home | Recent activity | Latest 2 rows from the access history |
| My Record: Notes | Written by | Group consultations by doctor |
| Access tabs | Red badge count | Count of pending requests |
| Doctor: Patients | Filter chips (All, Can see, Waiting, ...) | Filter by request status |
| Doctor: Scan | Recent scans | Latest QR scans by this doctor |
| Doctor: Profile | This month counts | Count rows in the existing tables |
| Doctor: Emergency | Ends after 1 hour | Compare the log time to now when opening the record |
| Printable ID | Print page | Browser print-to-PDF, never the password |
| Settings | Change password | Only if a set-password method exists, otherwise C |
| Settings | Text size Normal/Large | A CSS class saved in the session, no database |
| Phone | Gear opens Settings, tab bar links | Plain links |

## C. Placeholder for the demo (needs new tables or columns)
| Screen | Feature | Why not now |
|---|---|---|
| My Record: Care history | Admissions, ER visits, surgeries timeline, filter chips | Needs care-event tables |
| My Record: Care history | Places you've been treated | Needs facility data |
| My Record: Care history | Hide an entry (···), "1 entry hidden" | Needs a hidden flag plus logic on the doctor side |
| Doctor: open record | Seen elsewhere | Same care-event tables |
| Home ID card, My Record: Medical | Last vaccine, Vaccinations | Needs a vaccinations table |
| My Record: Medical | Conditions, allergy severity | New columns |
| My Record: Notes | Prescribed in these notes | Needs prescriptions linked to notes |
| My Record: Info, Profile | Emergency contact, height and weight, Edit links | New columns plus an edit form |
| Doctor: Profile | License no., clinic, Edit | New columns plus a form |
| Settings | Notification toggles, "Let doctors find me by ID", "Show my clinic" | New columns plus logic |
| Settings | Hidden care history link | Depends on hiding entries |
| Home after Allow | Undo on the toast | Needs a short undo window, so leave the button static |
| Access: Requests | "If you allow, the doctor can see" | Static text by design |

## D. Placeholder, long-term only
| Feature | Why |
|---|---|
| Language: Filipino | Full translation of every string |
| Real hospital and clinic records feeding care history | Needs data from other systems |
| Verifying doctor licenses (PRC) | Needs an outside service |
| Live camera scanning on every device | Depends on the browser and HTTPS. Keep the demo flow you have |
| Push notifications to the phone | Needs a notification service |

## Rules for Claude Code
- Build A first, then B. Never start C or D as real features before the exam.
- Every C and D item is static HTML in the template, marked `{# demo placeholder #}`, with the sample data from the reference page.
- A placeholder button can be a plain link to `#` or disabled. It must never pretend to save.
