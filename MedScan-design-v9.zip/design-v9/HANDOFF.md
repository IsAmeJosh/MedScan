# MedScan design v9 handoff

This is the target UI. It is the v6 UI you already built, refined in small steps, not a redesign. The layout and pages stay the same.

Open `reference/*.html` in a browser to see each page exactly as intended. They use `reference/ms-final.css`. Screenshots are in `screens/`.

## What changed since v6

### Look (steps 1 to 5, files in `css/`)
Each file is a small layer on top of the v6 stylesheet. Merge them into `G_Style.css` in order, as normal rules. The `!important` flags are only there because the mockups stacked layers; drop them once a rule replaces the original.

1. **One surface language (s1).** Every card and panel has the same 18px radius and the same soft shadow, with no borders. The ID card loses its decorative ring.
2. **Quieter details (s2).** Allergies are small tags with a red dot. The ID is plain text, list rows have no icon tiles, and secondary buttons are soft fills.
3. **Gradient as a brand thread (s3).** One teal gradient (#0F7F7D to #0B5A5F) is used only on the sidebar, the patient ID card and primary buttons. Everything else is flat.
4. **Four materials, four depths (s4).** See `screens/00-materials.png`.
   - Base #EEF4F3 is the page, and also the fill for secondary buttons, avatars and search.
   - Surface is white, used for cards and panels.
   - Brand gradient, as above.
   - Glass (frosted, `backdrop-filter: blur`) is only for the sticky top bar and the phone tab bar.
   - Pop-ups dim the page to 38% and blur it 8px (`.scrim` and `.sheet`).
5. **Polish (s5).**
   - The same inner padding everywhere: 24px on PC, 20px on phone.
   - Avatars and icons share one 36px round column.
   - The ID card facts are a grid with the label above the value.
   - Decline and Allow have a fixed size.
   - The phone tab bar has five equal slots. My QR is the same size, filled teal.

### Logo
The tile is gone. The scan frame stands alone at 34px, with the pulse line in mint #5FD3C4 on the sidebar and green #12A383 on light backgrounds. The tile stays only on the app icon and the PDF.

### Boxes rule
- A box holds one thing you act on (the ID card, a request, the note form) or one group of related rows (activity, care team, notes).
- No box inside a box.
- At most 3 boxes on a PC screen.

### Home (patient)
- The ID card shows name, ID, sex, age, blood type and allergy tags. Underneath is a facts grid: Taking, Last vaccine, Last visit, Surgery.
- "Needs your answer" has the request time in the corner, and Decline and Allow look identical. Consent must be freely given.
- The right panel holds Your care team (doctor, specialty, facility, last seen date) and Recent activity.
- The count strip (surgeries, visits) is removed. It read like a scoreboard.

### Care history (placeholders, static sample data, no database changes)
- **My Record > Care history tab** (`11-patient-care-history.html`): one timeline of consultations, an admission, an ER visit and a surgery, with filter chips and "Places you've been treated". One entry shows "Hidden from doctors".
- **Doctor's patient page:** "Seen elsewhere" under At a glance, plus "The patient has hidden 1 entry".
- These are hard-coded in the templates for the demo. Mark them clearly in the code as placeholders.

### Save-your-ID screen (after registering) and PDF
- `05-id-ready.html`: a big ID, a "Download as PDF" button, an "I saved my MedScan ID" checkbox, then Continue.
- `06-id-pdf.html` is the printable page, done with the browser's print-to-PDF; no PDF library is needed.
- It shows the ID, name, account type, created date and a masked mobile number. **Never the password.**

### Ethics fixes
- Declined requests get a grey "Declined" pill.
- No contact number on Home.
- Emergency access shows when it ended.

### Profile and Settings (s6)
- **Sidebar:** remove the "Account" label. Profile and Settings sit right under Access. The user block at the bottom of the sidebar has no arrow and is not a menu.
- **Profile** (`reference/30-patient-profile.html`) shows who you are, plus the health facts that rarely change. It has no account actions.
  1. A header with no box: a round avatar, name, MedScan ID and "Patient since".
  2. Personal details (one Edit link): Date of birth (age), Sex, Blood type, Mobile.
  3. Emergency contact (one Edit link): Name, Relationship, Mobile. This is a placeholder unless the data exists.
  4. Health at a glance (link to My Record): allergies as red-dot tags, Conditions, Medication, Last vaccine.
  5. Recent care (link to Care history): the latest 3 entries.
  - PC: two columns. The left one holds Personal details and Emergency contact in one panel. The right one holds Health at a glance, then Recent care.
  - Phone: one column in the order 1, 4, 5, then 2 and 3. The gear in the top bar opens Settings, as on every phone page.
- **Settings** (`reference/31-patient-settings.html`):
  - Notifications: Access requests, and Record opened (toggles). Emergency access is locked on.
  - Privacy: Let doctors find me by ID (toggle), and Hidden care history (link).
  - Account: Download my MedScan ID, Change password, and **Log out** (red). Log out lives only here.
  - Display: Text size, Normal or Large.
- The toggles and care rows are demo placeholders unless the logic already exists. Mark them in the template.

### Phone tab bar (s6, latest)
- The bar is flat and full width, attached to the bottom edge.
- It has no rounded corners, no side gaps and no shadow. It's solid white with a thin top line.
- It has five equal slots, and My QR is a teal tile the same size as the others.
- On phone, a gear (cog) icon sits in the top bar of every page and opens Settings. On Settings itself the gear is tinted to show you're there. It is not a theme switch.

### Quality pass (s7, latest)
Checked every screen against accessibility and touch rules (contrast, text size, tap size, focus, motion). Nothing moves; it only gets easier to read and use.
- Greys: `--muted` is now #4E676B and `--faint` is #5B7175, and the sidebar's secondary text is #B5D3D2. Every text colour passes 4.5:1 on white and on the page background. The green and amber pill text is darker too.
- No text under 12px. The phone tab labels are 12px, and the red badge is 12px in a 19px circle.
- Tap targets: icon buttons are 44x44. Text links like "Edit" and "Care history" get a 44px tall hit area through padding with a negative margin, so the layout doesn't move.
- One focus ring (2px brand teal, 2px offset) on every control. A light 0.97 press on buttons. Motion turns off when the device asks for reduced motion.
- Numbers use tabular figures (IDs, times, dates). Headings use balanced wrapping.
- The doctor's big patient avatar is round like every other avatar.
- New states: `reference/12b-home-after-allow.html` (the answer card empties to "You're all caught up", and a toast in the brand teal gradient says "Allowed…" with an underlined Undo) and `reference/13-qr-expired.html` (blurred code, "Make a new code"). After Allow or Decline, the Access badge goes away.

### The rest of the screens (latest)
Every screen now has a v9 reference page in `reference/`. New: 01 log in, 02 create account (keep the existing date-of-birth calendar), 12 to 13 Access Requests and Doctors, 15 to 17 My Record Notes, Medical (with vaccinations) and Info, 18 review a request (equal Decline and Allow), 19 notifications drawer, 32 log out confirm (opened from Settings only), 21 doctor patients, 22 locked record, 24 scan, 25 find a patient, 26 emergency access (reason required, ends after 1 hour), 27 doctor profile, 28 doctor settings.
- Settings is in the sidebar on every page, under Profile. On phone it opens from the gear in the top bar.
- The page top is tighter: content starts 28px under the top bar on PC and 14px on phone.
- `screens/00-all-pc.png` and `screens/00-all-phone.png` show all 29 screens in order.

### One grid for every page (s8, latest, replaces earlier layout notes where they differ)
- Every block starts at the content's left edge and ends at its right edge. No narrow or centred panels.
- Header: same spot and shape on every page. Title, an optional status pill next to it, and one line under it. No avatars in headers.
- Tabs: one style everywhere (underline, full width), directly under the header. The grey segmented tabs are gone.
- Columns: main plus a 360px side column, or two equal halves. Both columns end on the same line. Home is two rows: ID card + Needs your answer, then Care team + Recent activity.
- No loose helper text under panels. What mattered moved into the page subtitle or into a row (the doctor sees "1 entry hidden by the patient" as a row in Seen elsewhere).
- Home after Allow is now `12b-home-after-allow.html`.
