# MedScan v9 build steps

Do these in order, one per chat. The date-of-birth calendar (G_Register.html, G_Fields.js and its CSS) is already in place: keep it working and don't remove its styles.

1. **Styles.** Merge `css/s1.css` to `s8.css`, in order, into `gui/static/css/G_Style.css`. Match the class names the templates use. Drop `!important` where a rule now replaces the original. Update the logo in G_Icons.py and G_Base.html (no tile, mint pulse on the sidebar).
2. **Shell.** G_Base.html: sidebar with Settings under Profile for both roles, no "Account" label, no arrow in the user block. Phone: flat full-width tab bar with 5 equal slots, gear in the top bar of every page. One page header and underline tabs, as in the reference pages.
3. **Patient Home** (reference 10, 12b, 13): two rows. Row 1 has the ID card and Needs your answer (equal Decline and Allow). Row 2 has Your care team and Recent activity. After Allow or Decline, show the teal toast (Django message) and "You're all caught up". Add the QR pop-up and its expired state.
4. **My Record** (reference 15, 11, 16, 17): the Notes, Care history, Medical and Info tabs. Care history, vaccinations and "Prescribed in these notes" are demo placeholders.
5. **Access** (reference 12, 18, 13, 14): Requests, the review pop-up, Doctors and History.
6. **Profile, Settings, Log out** (reference 30, 31, 32). Log out only lives in Settings.
7. **Login, register, save your ID, printable ID** (reference 01, 02, 05, 06). Never show the password.
8. **Doctor pages** (reference 20, 21, 22, 26, 23, 24, 25, 27, 28): home, patients, locked record, emergency access, open record (with Seen elsewhere and "1 entry hidden by the patient"), scan, search, profile, settings.
9. **Final check.** Go through every reference page and list any template that still differs. Fix only those.
